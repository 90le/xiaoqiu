---
name: env-doctor
description: 本机环境一键体检：核心命令、服务、定时任务、档案版本化、存储、网络、adbc 通道、会话记录、文档库九项检查，输出中文报告。怀疑环境出问题时、闪退恢复后、定期保养时使用。
---

# 环境自检

```bash
bash ~/.pi/agent/skills/env-doctor/scripts/doctor.sh
```

九项检查，✅/⚠/❌ 三级结果。处理后可重跑确认。

## 处置速查
- **服务 ❌**：`export SVDIR=$PREFIX/var/service && sv up <服务名>`；仍不行看 `sv status` 与日志 `$PREFIX/var/log/sv/<服务>/current`
- **网络 ⚠**：用 network-fix 技能（fake-ip 劫持 → DoH 写 hosts）
- **adbc ⚠**：让用户开一次 设置→开发者选项→无线调试
- **存储 ⚠**：用 phone-cleanup 技能
- **档案 ❌**：禁止重装/清空，先向用户报告
