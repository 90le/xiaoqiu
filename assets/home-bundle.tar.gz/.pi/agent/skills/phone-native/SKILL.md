---
name: phone-native
description: 通过 小丘 App 的 MCP 服务器（127.0.0.1:8181）操作手机原生能力：可点击通知、剪贴板、TTS 朗读、震动、手电筒、音量、亮度、网络、应用管理、位置、短信、通话记录、联系人、文件、UI 点击滑动、Termux 联动。需要操作手机本体时优先用本技能（adb adbc 是备用通道）。
---

> ⚠️ 本技能原为 ZeroTermux 侧编写，提及 adbc/termux 命令处在本环境（com.pihost）一律不存在。等价能力请用 MCP 工具：l2_exec / env_run / ui_* / vd（见 phone-control 与 silent-control 技能）。以下原文仅作能力对照参考。


# 手机原生操控（小丘 App）

自研 App「小丘」（com.binbin.pibridge）内嵌 MCP 服务器，33 个原生工具。
**调用方式**：MCP 网关的 `mcp__phone` 代理（工具名带 phone_ 前缀），或直接 HTTP：

```bash
curl -s -X POST http://127.0.0.1:8181/api/工具名 -H "Content-Type: application/json" -d '{"参数":"值"}'
```

## 工具清单（phone_tools_list 可实时查）
- **通知**：notify_post（可点击开 URL！）、notify_cancel
- **剪贴板**：clipboard_write ✅ / clipboard_read（Android10+ 可能拒绝）
- **语音/触感**：tts_speak（中文朗读）、vibrate
- **硬件**：flashlight 手电筒、brightness_get/set、volume_get/set、media_play_pause
- **信息**：battery_status、device_info、screen_state、network_info
- **应用**：apps_list、apps_launch
- **个人数据**（需权限，已授）：sms_list、calllog_list、contacts_search、location_last
- **文件**（共享存储）：files_list、files_read_text、files_write_text
- **UI 操控**（需辅助服务）：ui_back、ui_home、ui_recents、ui_tap、ui_swipe
- **Termux 联动**：termux_queue（投递脚本，crond 每分钟执行，100% 可用）、termux_run（需 RUN_COMMAND 权限，被 HyperOS 锁，备用）
- **权限**：app_request_permission（弹窗求授权）、tools_list

## 用法纪律
- 通知类操作优先本通道（可点击）；adbc cmd notification 是无点击兜底
- 个人数据（短信/通话/联系人）读取后不向第三方外传，不在回复中大段复述隐私内容
- 脚本要在 Termux 执行 → termux_queue（延迟≤1分钟）；急事直接自己跑（本会话就在 Termux 里）
- 服务器没响应时：`adbc shell am start -n com.binbin.pibridge/.MainActivity` 拉起

## 授权状态（2026-09-01）
已授：短信/通话记录/定位/相机/通知/辅助服务/外部存储/系统设置/悬浮窗
缺失：RUN_COMMAND（HyperOS 锁死 pm grant，弹窗也被吞）→ 用 termux_queue 代替

## 感知与直设三件套（2026-09-01 新增，强烈推荐优先用）

- **phone_ui_screen_read**：读取当前屏幕控件树（JSON：text/id/xy/click/edit/pwd/scroll）。
  AI"看见"界面的首选——比截图喂视觉快 10 倍且准。先 read 再决策点哪。
- **phone_ui_set_text**：直接设置焦点输入框文本（ACTION_SET_TEXT），一步到位。
  彻底取代"剪贴板+长按+粘贴菜单"老四样。对 WebView/Chrome 输入框同样有效。
  注意：终端类自定义 View（如 Termux 终端）不是 EditText，set_text 无效——那种场景仍需剪贴板+长按，或走 termux_run/队列桥。
- **phone_screenshot**：无障碍通道截当前屏（Android 11+），PNG 存 /storage/emulated/0/pibridge/shots/。
  读屏拿不到的视觉信息（图片/地图/复杂布局）再用它兜底。

**操作纪律**：能用 L1 系统调用（Intent/Provider/文件）绝不碰 UI；UI 操作先 screen_read 看清再 tap/set_text。
**坑**：HyperOS 下每次重装 小丘 APK，无障碍开关可能被系统重置——需手动重开
（若"USB调试(安全设置)"开启则可用 settings put 自动化，pm grant/input 也一并解锁）。
