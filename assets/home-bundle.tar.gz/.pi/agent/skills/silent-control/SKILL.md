# 隐形后台操控（silent-control）

在隐形虚拟副屏上操作任意 App，用户主屏完全无感。适用于：用户在用手机时你悄悄完成任务、自动化巡检、批量操作。

## 标准操作循环

1. `vd {action:"create"}` → 返回 displayId（如 7）
2. `vd {action:"launch", pkg:"包名"}` → 目标 App 发射到副屏
3. `ui_screen_read {display: 7}` → 读副屏结构树（编号/文本/坐标/可点击）
4. 用树里的坐标中心点：`vd {action:"tap", x, y}`
5. **必验证**：再读一次树，确认页面已到达预期状态
6. 完成：`vd {action:"stop"}` 销毁副屏（不留痕迹）

## 要点

- 结构树优先于截图：树里有精确坐标和文本，比视觉猜坐标可靠得多
- 坐标取 xy 区域中心：x + w/2, y + h/2
- 滑动：`vd {action:"swipe", x, y, x2, y2}`（副屏坐标系 900x2000）
- 文字输入：`vd {action:"text", text:"..."}`（空格用 %s）
- 看一眼画面：`vd {action:"shot"}` 返回 PNG 路径（视觉辅助/调试用）
- displayId 每次创建会变，以 create 返回为准；App 重启后副屏失效需重建
- launch 走 L2 shell 兜底（MIUI 拦 App 内通道），耗时 2-5 秒属正常
- 支付/发送/删除类破坏性操作，副屏上也必须先问用户

## 常用包名

- 设置 com.android.settings · 微信 com.tencent.mm · 支付宝 com.eg.android.AlipayGphone
- 相册 com.miui.gallery · 时钟 com.android.deskclock · 计算器 com.miui.calculator
