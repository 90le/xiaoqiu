---
name: crash-recovery
description: App 闪退后找回对话断点：解析最新的 pi 会话记录，还原最后在聊什么、执行到哪一步。闪退/断电/误关后立即使用。
---

# 闪退恢复

pi 的对话原文存在磁盘上，**闪退不丢历史**。恢复流程：

## 1. 一键还原断点
```bash
node ~/.pi/agent/skills/crash-recovery/scripts/latest.mjs
```
输出最近两个会话文件的：对话条数、最后的工具调用序列、最后 3 条消息摘要。

## 2. 向用户复述断点
"上次断在：〈最后用户指令〉，我执行到〈最后动作〉"——然后接着干，不要重问背景。

## 3. 若需要更多上下文
会话 jsonl 在 `~/.pi/agent/sessions/<目录>/时间戳_uuid.jsonl`，每行一个 JSON，
`message.role` = user/assistant，`message.content` 里 type=text 是发言、type=toolCall 是工具调用。
用 node 流式解析（参考 scripts/latest.mjs 的写法），不要整读大文件。

## 4. 长任务防再断
恢复工作后，重活放 tmux 会话里跑（`tmux new -s 干活`），App 再闪退任务不死。
