#!/data/data/com.termux/files/usr/bin/node
// latest.mjs —— 找最新会话记录，还原断点（最后 3 条对话消息）
import fs from "node:fs";
import path from "node:path";
import os from "node:os";

const root = path.join(os.homedir(), ".pi/agent/sessions");
const files = [];
(function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p);
    else if (e.name.endsWith(".jsonl")) files.push({ p, t: fs.statSync(p).mtimeMs });
  }
})(root);
files.sort((a, b) => b.t - a.t);

for (const f of files.slice(0, 2)) {
  const msgs = [];
  for (const line of fs.readFileSync(f.p, "utf8").split("\n")) {
    if (!line.trim()) continue;
    let o; try { o = JSON.parse(line); } catch { continue; }
    const m = o.message || o;
    if (m.role !== "user" && m.role !== "assistant") continue;
    const c = m.content;
    const txt = Array.isArray(c) ? c.filter(x => x?.type === "text").map(x => x.text).join(" ") : String(c ?? "");
    const t = txt.replace(/\s+/g, " ").trim();
    if (t) msgs.push([m.role, t]);
  }
  const toolCalls = [];
  for (const line of fs.readFileSync(f.p, "utf8").split("\n")) {
    let o; try { o = JSON.parse(line); } catch { continue; }
    const c = (o.message || o)?.content;
    if (Array.isArray(c)) for (const x of c) if (x?.type === "toolCall") toolCalls.push(x.name);
  }
  console.log(`\n📄 ${path.basename(f.p)}（${msgs.length} 条对话，${toolCalls.length} 次工具调用）`);
  console.log(`   最后动作: ${toolCalls.slice(-3).join(" → ") || "无"}`);
  for (const [r, t] of msgs.slice(-3)) console.log(`[${r}] ${t.slice(0, 200)}`);
}
