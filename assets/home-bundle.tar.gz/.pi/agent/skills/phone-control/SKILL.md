---
name: phone-control
description: 通过 adbc 操控 Android 手机本体：截图、安装卸载应用、取崩溃日志、查电池/存储、禁用应用、toast 提示等。当需要手机系统能力或排查手机侧问题时使用。
---

# 手机管控（adb via 127.0.0.1）

本机（ZeroTermux）与手机系统同宿主，adb 走本机回环直连无线调试，**无需 VM、无需配对**（密钥已部署 `~/.android/adbkey`）。

## 连接
```bash
adbc                # 自动扫 127.0.0.1:30000-60000，连上后透传任意 adb 命令
adbc shell echo ok  # 透传示例
```
- 报连不上 → 手机「设置→开发者选项→无线调试」开关被重启清掉了，请用户开一次
- VM 侧等价命令走网关 10.51.238.97（见档案手册.md）

## 高频操作速查
```bash
adbc shell dumpsys battery            # 电量/充电状态
adbc shell df -h /sdcard              # 存储余量
adbc shell pm list packages | grep x  # 查包名
adbc shell pm uninstall --user 0 包名 # 卸载（可逆！恢复见下）
adbc shell cmd package install-existing 包名  # 恢复已卸系统应用
adbc shell pm disable-user 包名       # 禁用（卸不掉的 MIUI 应用）；恢复=pm enable
adbc shell logcat -b crash -d         # 崩溃日志（闪退后第一时间取证！缓冲区跨重启保留）
adbc exec-out screencap -p > /sdcard/Download/s.png  # 截图到下载目录
adbc install xx.apk                   # 安装
adbc shell settings get global xxx    # 读系统设置
```

## 本机 App 闪退取证（ZeroTermux 自身）
App 闪退后重开，尽快跑 `adbc shell logcat -b crash -d`（崩溃缓冲区不会因 App 重启丢）。
已知闪退模式（VM 时代日志）：内存压力 → 系统查杀 → 关闭竞态 bug。对策：防杀三件套 + 少截图 + 重活在 tmux 里跑。

## 屏幕视觉（2026-08-31 实测可用）
我能看见手机屏幕：`adbc exec-out screencap -p > $PREFIX/tmp/s.png` 后用 read 工具读图（glm 视觉）。适用：排屏上报错、读代码、看画面。注意：截图含隐私，用完即删；投屏/远程桌面时抓到的是被投内容。

## 红线
- 卸载/禁用系统组件前先和用户确认，记录到会话日志，并给出恢复命令
- 不动 `com.termux*`、`com.android.virtualization.*`（终端 App 与本环境本体）
