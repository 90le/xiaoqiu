---
name: phone-control
description: 手机系统能力操作（小丘 App 内）：静默设置读写、隐形副屏操控、界面读写点击、应用管理、截图。需要操控手机或排查手机侧问题时使用。
---

# 手机管控（com.pihost 原生，MCP 工具）

**本环境没有 adbc/termux 命令。** 一切系统级操作走 MCP 工具（127.0.0.1:8181）。

## 能力速查

| 任务 | 正确姿势 |
|---|---|
| 读系统开关（WiFi/蓝牙/飞行模式） | `network_info`（免权限直读）或 `l2_exec {cmd:"settings get global wifi_on"}` |
| 静默改系统设置 | `l2_exec {cmd:"settings put ..."} `（L2 特权通道）|
| 后台操作 App（用户无感） | `vd` 隐形副屏 + `ui_screen_read {display:N}`（见 silent-control 技能）|
| 读前台界面 | `ui_screen_read`（结构树优先于截图）|
| 点击/滑动/输入 | `ui_tap / ui_swipe / ui_set_text`（主屏）；`vd tap/swipe/text`（副屏）|
| 截图 | `screenshot`（无障碍通道）|
| 开关手电/振动/音量/亮度 | `flashlight / vibrate / volume_set / brightness_set` |
| 装卸/启动/查应用 | `apps_launch / apps_list / l2_exec pm ...` |
| 电池/设备信息 | `battery_status / device_info` |
| 通知 | `notify_post / notify_cancel` |

## 操作决策循环

1. 能用 settings/content 命令查改的，绝不碰界面（L1）
2. 必须碰界面时优先隐形副屏（用户无感）
3. 动手后必验证（再读一次状态/树）

## 禁手

- ❌ 在环境里找 adbc / adb / termux —— 不存在
- ❌ 用打开前台界面的方式做"查询类"任务（污染用户屏幕）
- ❌ 删除/支付/发送类操作不问用户
