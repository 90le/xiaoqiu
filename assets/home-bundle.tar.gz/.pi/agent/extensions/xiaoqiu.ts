// xiaoqiu.ts —— 小丘全量工具桥接扩展
// 把 App 的 MCP 工具（vd/l2_exec/ui_*/network_info 等）注册为 pi 原生工具
// 内部转发到 http://127.0.0.1:8181/api/{name}
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";

async function callApi(name: string, args: Record<string, unknown> | undefined): Promise<string> {
  const res = await fetch(`http://127.0.0.1:8181/api/${name}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(args ?? {}),
  });
  if (!res.ok) throw new Error(`API ${name} HTTP ${res.status}（App 未运行?）`);
  const j: any = await res.json();
  // MCP 形状: {content:[{type:"text",text:JSON字符串}]}；也可能直接是结构化
  let inner: any = j;
  try {
    if (j?.content?.[0]?.text) inner = JSON.parse(j.content[0].text);
  } catch {}
  if (inner && inner.ok === false) {
    const e = inner.error ?? {};
    throw new Error(`${e.code ?? "ERR"}: ${e.message ?? JSON.stringify(inner)}`);
  }
  return JSON.stringify(inner.data ?? inner, null, 1);
}

function simple(name: string, label: string, desc: string, props?: any, required?: string[]) {
  return {
    name,
    label,
    description: desc,
    parameters: Type.Object(props ?? {}, { required: required ?? [] }),
    async execute(_id: string, params: Record<string, unknown>) {
      const text = await callApi(name, params);
      return { content: [{ type: "text", text }], details: {} };
    },
  };
}

export default function (pi: ExtensionAPI) {
  // ── 状态查询（L1，免界面）──
  pi.registerTool(simple("network_info", "查网络", "查 WiFi/蓝牙/飞行模式/流量开关+在线状态，免权限免界面"));
  pi.registerTool(simple("battery_status", "查电池", "电量、充电状态、温度"));

  // ── 主屏界面 ──
  pi.registerTool(simple("ui_screen_read", "读屏幕结构树",
    "读取屏幕控件树（结构化 JSON：编号/文本/坐标/可点击性）。display=0 主屏；传隐形副屏 displayId 可读副屏。操控界面优先用它而非截图",
    { display: Type.Optional(Type.Number({ description: "屏幕ID 默认0主屏" })) }));
  pi.registerTool(simple("ui_tap", "点击屏幕", "点击主屏坐标", {
    x: Type.Number({ description: "x" }), y: Type.Number({ description: "y" }),
  }, ["x", "y"]));
  pi.registerTool(simple("ui_swipe", "滑动屏幕", "主屏滑动", {
    x1: Type.Number(), y1: Type.Number(), x2: Type.Number(), y2: Type.Number(),
    ms: Type.Optional(Type.Number({ description: "时长毫秒 默认300" })),
  }, ["x1", "y1", "x2", "y2"]));
  pi.registerTool(simple("ui_tap_node", "按编号点击",
    "按结构树编号直接点击节点中心（先 ui_screen_read 得编号 i，免算坐标最可靠）。主屏默认；副屏传 display",
    {
      i: Type.Number({ description: "节点编号" }),
      display: Type.Optional(Type.Number({ description: "屏幕ID 默认0主屏" })),
    }, ["i"]));
  pi.registerTool(simple("wait_node", "等待内容出现",
    "页面加载/跳转后轮询结构树等文本出现（比盲等可靠），找到即返回节点信息",
    {
      text: Type.String({ description: "等待出现的文本" }),
      display: Type.Optional(Type.Number()),
      timeout_sec: Type.Optional(Type.Number({ description: "默认10秒" })),
    }, ["text"]));
  pi.registerTool(simple("ui_set_text", "设置输入框文本", "对焦点输入框直设文本；display 传副屏ID可在隐形副屏输入（支持中文）", {
    text: Type.String({ description: "文本" }),
    display: Type.Optional(Type.Number({ description: "屏幕ID 默认0主屏" })),
  }, ["text"]));
  pi.registerTool(simple("sysctl", "系统开关",
    "系统开关静默控制（免界面秒级）：read 读全部状态；wifi/bluetooth/rotate/location/dnd/brightness_auto 切换（on=true开 false关），执行后自动回读校验",
    {
      action: Type.String({ description: "read/wifi/bluetooth/rotate/location/dnd/brightness_auto" }),
      on: Type.Optional(Type.Boolean({ description: "true=开 false=关" })),
    }, ["action"]));
  pi.registerTool(simple("screenshot", "截图", "截主屏（无障碍通道），返回 PNG 路径"));

  // ── 隐形副屏（后台操控核心）──
  pi.registerTool(simple("vd", "隐形副屏操控",
    "在隐形虚拟副屏上后台操作任意App（用户主屏无感）。action: create创建/launch发射App/shot截副屏/tap点击/swipe滑动/text输入/info状态/stop销毁。标准循环：create→launch→ui_screen_read(display=N)→tap→读树验证→stop",
    {
      action: Type.String({ description: "create/launch/shot/shot_grid(网格标注视觉)/tap/longpress/swipe/text/key/scroll_until/info/stop" }),
      pkg: Type.Optional(Type.String({ description: "launch: 应用包名" })),
      x: Type.Optional(Type.Number()), y: Type.Optional(Type.Number()),
      x2: Type.Optional(Type.Number()), y2: Type.Optional(Type.Number()),
      text: Type.Optional(Type.String()),
      w: Type.Optional(Type.Number()), h: Type.Optional(Type.Number()),
    }, ["action"]));

  // ── 特权与应用 ──
  pi.registerTool(simple("l2_exec", "特权shell",
    "以 shell 特权执行系统命令（settings put/get、pm、am、input、dumpsys 等）。查询类任务优先用命令而非开界面",
    {
      cmd: Type.String({ description: "单行命令" }),
      timeout_sec: Type.Optional(Type.Number({ description: "超时秒 默认30" })),
    }, ["cmd"]));
  pi.registerTool(simple("apps_launch", "启动应用", "启动指定包名应用", {
    package: Type.String({ description: "包名" }),
  }, ["package"]));
  pi.registerTool(simple("apps_list", "列应用", "列出已装应用（可关键词过滤）", {
    filter: Type.Optional(Type.String()), limit: Type.Optional(Type.Number()),
  }));

  pi.registerTool(simple("notify_read", "读通知",
    "读取捕获的通知（微信/短信/物流等，最新在前）。'听'的核心：可及时发现新消息。首次需用户在 系统设置→通知使用权 授权小丘",
    {
      limit: Type.Optional(Type.Number({ description: "条数 默认20" })),
      pkg: Type.Optional(Type.String({ description: "按包名过滤 如 com.tencent.mm" })),
    }));
  pi.registerTool(simple("ui_list_extract", "列表批量抽取",
    "信息流/商品/搜索结果批量抽取：自动滚动+树合并去重。配合隐形副屏可抽取任意App列表",
    {
      display: Type.Optional(Type.Number()),
      max_swipes: Type.Optional(Type.Number({ description: "最多滑动次数 默认5" })),
      contains: Type.Optional(Type.String({ description: "只保留含关键词的条目" })),
    }));
  pi.registerTool(simple("ui_page_info", "页面速览",
    "当前屏的包名/节点数/主要文本——快速判断现在在哪个App哪个页面",
    { display: Type.Optional(Type.Number()) }));

  pi.registerTool(simple("ime_switch", "切换输入法",
    "adb=ADBKeyboard（自动化中文广播注入）/ sogou=搜狗（还给用户）。微信类反自动化App的中文输入前置步骤，任务完成务必切回 sogou",
    { target: Type.String({ description: "adb 或 sogou" }) }, ["target"]));

  pi.registerTool(simple("vision_ask", "视觉问答（pi的眼睛）",
    "对本地图片提问，GLM-4V 返回文字答案。无结构树的App（微信等）用 shot/vd shot_grid 截图后 vision_ask 理解界面、找按钮坐标。示例：q='找到搜索按钮，返回其中心坐标'",
    {
      file: Type.String({ description: "图片路径" }),
      q: Type.String({ description: "问题" }),
    }, ["file", "q"]));

  // ── 万能兜底：直达任意 App 工具 ──
  pi.registerTool({
    name: "xiaoqiu_api",
    label: "小丘万能工具调用",
    description:
      "直达小丘全部 55 个工具的万能入口（工具名见 /api/tools_list）。仅当上面专用工具不够用时使用，如 tts_speak/notify_post/files_*/sms_list/contacts_search 等",
    parameters: Type.Object({
      tool: Type.String({ description: "工具名，如 tts_speak" }),
      args: Type.String({ description: "JSON 对象字符串，如 {\"text\":\"你好\"}" }),
    }, { required: ["tool"] }),
    async execute(_id: string, params: Record<string, unknown>) {
      let args: any = {};
      try { args = params.args ? JSON.parse(String(params.args)) : {}; } catch { throw new Error("args 不是合法 JSON"); }
      const text = await callApi(String(params.tool), args);
      return { content: [{ type: "text", text }], details: {} };
    },
  });
}
